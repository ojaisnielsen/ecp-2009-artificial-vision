Video sequence courtesy of Nilanjan Ray, University of Alberta, Department of Computer Science.
http://www.cs.ualberta.ca/~nray1/CMPUT617/HW/Cyclists/
