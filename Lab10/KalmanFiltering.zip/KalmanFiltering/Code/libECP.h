


#ifndef LIBECP_INCLUDED
#define LIBECP_INCLUDED





/**
* Reads Measurements from files
*/
int readMeasures(char * fileName, CImg<float>& measures)
{
  int nbPoints=0;
  
  fstream fs;
  fs.open(fileName, ios::in);
  if (!fs.is_open())
  {
   cout<<"File can't be opened!\n";
   return false;
  }
  
  fs>>nbPoints;
  
  measures.resize(1, nbPoints);
  int n=0;
  while (fs.good() && n<nbPoints)
  {
        fs>>measures(0,n);
        n++;
  }
  
  std::cout<<n<<" points have been loaded."<<std::endl;
  fs.close();
  
  return n;
}

/**
* Plots a vector of measurements
*/

void plotVector(const CImg<float>& measures)
{
    CImg<float> visu(500,400,1,3,0);
    const float red[] = { 1.0,0,0 }, green[] = { 0,1.0,0 }, blue[] = { 0,0,1.0 };
     
    CImgDisplay draw_disp(visu, "Curve");
    while (!draw_disp.is_closed) {
      //draw_disp.wait();
  
      visu.fill(1.0).draw_graph(measures,red).display(draw_disp);
  
    }
}










/**
* Loads a set of images and puts them in a CImgList
* @param images the CImgList<float> in which the new images will be pushed back
* @param path complete path with trailing / e.g: "/home/user/images/"
* @param prefix prefix of the file names
* @param indexMin the files should be indexed between indexMin and indexMax (included)
* @param indexMax 
* @param indexStep 
* @param extension type of the files (without "."). e.g: "png", "jpg", "jpeg"...
*/
void loadImages(CImgList<float>& images, char* path, char* prefix, int indexMin, int indexMax, int indexStep, char* extension )
{
	char fileName[1000];
	for( int index = indexMin; index <= indexMax; index += indexStep ) 
	{
		sprintf( fileName, "%s%s%04d.%s", path, prefix, index, extension );
		
		// Create and load image
		CImg<float> newImg( fileName );
		// Convert the image to grayscale by averaging the 3 RGB channels
		newImg = newImg.get_channel(0) + newImg.get_channel(1) +  newImg.get_channel(2);
		newImg/=3.0; 
		
		// Put image in list 
		images.push_back( newImg );
	}
} 



/**
*Measures the position of the target in the current frame using normalized correlation with a reference template 
*Returns the value of the maximum of correlation in the search window
* @param currentFrame contains the current frame
* @param referenceTemplate a template of the target (usually given by manual initialization on the first frame)
* @param previousPosition position of the target in the previous frame (1x2 vector)
* @param currentPosition position of the target in the current frame (1x2 vector)
* @param searchdx half of the width of the search window 
* @param searchdy half of the length of the search window  
*/

float measureCrossCorrelation (const CImg<float> & currentFrame,const CImg<float> & referenceTemplate, const CImg <int> & previousPosition, CImg <int> & currentPosition ,int searchdx, int searchdy )
{
	//TODO :fill this whole function which:
		//- compute the position of the best correlated subwindow (put the result in currentPosition)
		//- return a float containing the correlation value obtained at the best position

}



/**
*Computes the current state of a dynamic system using kalman filtering, knowing the previous state
* @param previousState 
* @param PkPrevious  estimate of the error in the previous step
* @param currentState 
* @param PkCurrent  estimate of the error in the current step
* @param zk measurement
* @param A matrix of state transition
* @param H matrix relating the measurement to the state
* @param Q covariance of the noise on the state
* @param R covariance of the noise on the measurement
*/

void twoStepKalmanFiltering(const CImg<float> & previousState, const CImg<float> & PkPrevious, CImg<float> & currentState, CImg<float> & PkCurrent, const CImg<int> & measurement,  const CImg<float> & A, const CImg<float> & H, const CImg<float> & Q, const CImg<float> & R) 
{
	//TODO :fill this whole function
	
	/// prediction step
	
	/// correction step
} 



/**
* Displays the position of the target in a frame
* @param frame 
* @param position center of the template
* @param halfWidth half of the width of the template
* @param halfLength half of the length of the template
* @param displayWindow 
*/                 
void displayTemplate (CImg<float> & frame, CImg <int> position, int halfWidth, int halfLength, CImgDisplay & displayWindow )
{
	CImg <unsigned char> imageWithTemplate(frame);
	
	unsigned char red [3] = {255,0,0};
	int xc= position(0);
	int yc= position(1);
	// draw the rectangle of the template
	imageWithTemplate.draw_line(xc-halfWidth, yc-halfLength, xc+halfWidth, yc-halfLength,red);
	imageWithTemplate.draw_line(xc+halfWidth, yc-halfLength, xc+halfWidth, yc+halfLength,red);
	imageWithTemplate.draw_line(xc+halfWidth, yc+halfLength, xc-halfWidth, yc+halfLength,red);
	imageWithTemplate.draw_line(xc-halfWidth, yc+halfLength, xc-halfWidth, yc-halfLength,red);
	
	
	displayWindow.resize(frame);
	imageWithTemplate.display(displayWindow);
	
	displayWindow.show();
	
}



/**
* Tracks a target in the sequence images using cross correlation only
* @param images 
* @param xInitial initial x-coordinate of the target
* @param yInitial initial y-coordinate of the target
* @param halfWidth
* @param halfLength
* @param searchdx half the width of the search window
* @param searchdy half the length of the search window
* @param displayWindow
*/     
void trackCrossCorrelation(CImgList<float> & images, int xInitial, int yInitial, int halfWidth, int halfLength, int searchdx, int searchdy, CImgDisplay & displayWindow )
{
	int imagesN = images.size;
	CImg <int> previousPosition (1,2) ; 
	CImg <int> currentPosition (1,2) ;
	
	previousPosition(0) = xInitial;
	previousPosition(1) = yInitial;
	
	CImg < float> referenceTemplate = images[0].get_crop(xInitial-halfWidth, yInitial-halfLength, xInitial+halfWidth,yInitial+halfLength) ;

	for (int i =1; i <imagesN;i++)
	{
	
		double corr=measureCrossCorrelation (images[i],referenceTemplate,previousPosition,currentPosition ,searchdx, searchdy);
		char title [100];
		sprintf(title,"Tracking with cross correlation [Frame %d]",i);
		cout<<"Position at frame "<<i<<": ("<<currentPosition(0)<<","<< currentPosition(1)<<")"<<endl;
		cout<<"Correalation at frame "<<i<<": "<<corr<<endl;
		displayWindow.set_title(title);
		displayTemplate (images[i], currentPosition, halfWidth, halfLength, displayWindow );

		previousPosition = currentPosition;
		cimg::wait(40);
		
	}

}

/**
* Tracks a target in the sequence images using cross correlation combined with Kalman filtering
* @param images 
* @param xInitial initial x-coordinate of the target
* @param yInitial initial y-coordinate of the target
* @param halfWidth
* @param halfLength
* @param searchdx half the width of the search window
* @param searchdy half the length of the search window
* @param displayWindow
*/    
void trackKalmanFiltering(CImgList<float> & images, int xInitial, int yInitial, int halfWidth, int halfLength,int searchdx, int searchdy, CImgDisplay & displayWindow )
{

int imageN = images.size;


/*the state is a 1x4 vector, the first two components represent the position of the target
the last two components are the velocities*/
CImg <float> previousState(1,4);
CImg <float> currentState(1,4);


CImg <int> previousPosition (1,2) ; 
CImg <int> currentPosition (1,2) ;
CImg <int> estimatedPosition (1,2) ;  

previousPosition(0,0)= xInitial;
previousPosition(0,1)= yInitial;

previousState(0,0) = xInitial;
previousState(0,1) = yInitial;
previousState(0,2) = 0;
previousState(0,3) = 0;

CImg < float> referenceTemplate = images[0].get_crop(xInitial-halfWidth, yInitial-halfLength,xInitial+halfWidth, yInitial+halfLength);


// matrix of state transition, we assume a constant velocity model of motion
CImg<float>  A = CImg <float> ::identity_matrix(4);
A(2,0)=1;
A(3,1)=1;
	
// matrix of transition from state to measurement
CImg<float> H (4,2);
H.fill(0);
H(0,0) = 1;
H(1,1) = 1;

	
//covariance of the noise on the state
CImg<float> Q = CImg <float> ::identity_matrix(4) * 5;
Q(2,2)=1;
Q(3,3)=1;
	
// covariance of the noise on the measurement
CImg<float>  R = CImg <float> ::identity_matrix(2) *50;
	
// A priori estimate of the error
CImg<float>  PkPrevious(4,4);
PkPrevious.fill(0);
	
// A posteriori estimate of the error
CImg<float>  PkCurrent(4,4);


for (int i =1; i <imageN;i++)
{
	// measure the correlation
	float maxCorrelation = measureCrossCorrelation (images[i],referenceTemplate,previousPosition,estimatedPosition ,searchdx,searchdy );
	
	
	/* increase the covariance on the noise of the measurement if the correlation if smaller than a threshold(0.5).
	* This is helpful to hold occlusions*/
	if ( maxCorrelation <=0.5)
	{
			R = CImg <float> ::identity_matrix(2) *10000;
	}
	else
	{
		R = CImg <float> ::identity_matrix(2) *50;
	}

	
	// use Kalman filtering to estimate the current state, using the measurement given by cross correlation
	twoStepKalmanFiltering(previousState, PkPrevious, currentState,PkCurrent, estimatedPosition,  A, H, Q, R) ;
	

	// update the position 
	currentPosition(0) = (int) currentState(0);
	currentPosition(1) = (int) currentState(1);
	
	// print the current position
	cout<<"Position at frame "<< i<<": ("<<currentPosition(0)<<","<< currentPosition(1)<<")"<<endl;
	cout<<"Speed at frame "<< i<<": ("<<currentState(2)<<","<< currentState(3)<<")"<<endl;
	
	char title [100];
	sprintf(title,"Tracking with Kalman filtering [Frame %d]",i);
	displayWindow.set_title(title);
	// display the result of the tracking  
	displayTemplate (images[i], currentPosition, halfWidth, halfLength, displayWindow );
	// update the previous state, the previous position and the previous estimate of the error
	previousPosition(0)= (int) currentState(0);
	previousPosition(1)=(int) currentState(1);
	previousState = currentState;
	PkPrevious = PkCurrent;
	
	cimg::wait(40);
}

}



/**
* Displays a sequence images
* @param images 
* @param displayWindow
*/ 
void displaySequence(CImgList<float> & images, CImgDisplay & displayWindow)
{
	int imageN = images.size;
	for (int i = 0; i <imageN;i++)
	{
		
		char title [100];
		sprintf(title,"Cyclists sequence [Frame %d]",i);
		displayWindow.set_title(title);
		images[i].display(displayWindow);
		displayWindow.show();
		cimg::wait(40);
		
			
	}

}     

#endif
