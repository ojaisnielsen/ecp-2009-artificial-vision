

#include <cstdlib>
#include <iostream>
//#include <time.h>
#include "CImg.h"
using namespace std;
using namespace cimg_library;

#include "libECP.h"


     
     
int main(int argc, char *argv[])
{
    
    CImgList<float> images ;
    
    loadImages(images,"./frames/", "longcoast_frame_", 0,199, 1,"bmp" );
    
    int imageN = images.size;
    cout << imageN << " images were loaded." << endl;
    
    
    // display windows for the sequence, the cross correlation tracking and the Kalman filtering tracking respectively
    CImgDisplay displayWindowSequence;
    CImgDisplay displayWindowCrossCorrelation;
    CImgDisplay displayWindowKalmanFiltering;
    
    displayWindowSequence.resize( images[0]);
    
    displayWindowCrossCorrelation.resize( images[0]);
    
    displayWindowKalmanFiltering.resize( images[0]);
    
    // display the test sequence without tracking
//     displaySequence(images, displayWindowSequence);

    /****** initial positions of different targets*****/
    
    /* first cyclist*/
    int xc =146;
    int yc = 62 ;
    
    /*second cyclist
    int xc =132;
    int yc = 85 ;*/
    
    /*third cyclist
    int xc = 137 ;
    int yc = 115 ; */
    
    /*fourth cyclist
    int xc =140;
    int yc = 144 ;*/

    
    /*fifth cyclist
    int xc =142;
    int yc = 170 ;
    */
    
    
    //half the width of the target
    int halfWidth = 10;
    //half the length of the target
    int halfLength = 15;
    
    
    // half the size of the search window
    int searchdx = 10;
    int searchdy = 10;
    
    
    // Tracking with cross correlation only
    cout <<"*******Cross Correlation tracking*******"<<endl;
    trackCrossCorrelation(images,xc,yc,halfWidth,halfLength,5,10,displayWindowCrossCorrelation);
    
    // tracking with Kalman filtering
    cout <<"*******Kalman filtering tracking*******"<<endl;
    trackKalmanFiltering(images,xc,yc,halfWidth,halfLength,searchdx,searchdy,displayWindowKalmanFiltering);
    
    
    //system("PAUSE");
    return 0;
}
