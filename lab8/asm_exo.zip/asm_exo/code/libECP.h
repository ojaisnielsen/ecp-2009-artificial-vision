#ifndef LIBECP_INCLUDED
#define LIBECP_INCLUDED

#include "EcpException.h"

#include <vector>
using namespace std;

#include <iostream>
#include <fstream>

double round(double a)
{
	return floor(a+0.5);
}
/**
 * Load an object from a file given by its entire path
 * @param fileName file name, complete with extension and all: /home/.../object.pts or C:\ilovecomputervision\imagefile.pts
 * @param object this will be resized if it is too small for the object described in the file.
 */

void makeObjectFromFile( char* fileName, CImg<float>& object )
{
	ifstream sourceFile;
	sourceFile.open( fileName );
	if( !sourceFile.is_open() )
		throw EcpException("makeContourFromFile: cannot open file");
			
	char line[100];
	char* line2;
	// read the first line of the file
	// which represents the dimension of the object
	int dimension;
	sourceFile.getline( line, 100 );
	line2 = line;
	while( line2[0] == ' ' )
		line2++;
	sscanf( line2, "%d", &dimension );
		
	// If the contour doesn't have the right dimension, resize it
	if( object.dimx() <= 0 )
	{
		if( object.dimy() < 2*dimension )
			object.resize( 1, 2*dimension );
		else
			object.resize( 1, object.dimy() );
	}
	if( object.dimy() < 2*dimension )
		object.resize( object.dimx(), 2*dimension );
	
	// read the file line by line
	float x, y;
	for( int i = 0; i < dimension; i++ )
	{
		sourceFile.getline( line, 100 );
		if( sourceFile.eof() && i < dimension - 1 )
			throw EcpException("Ecp2DContour: file does not contain enough coordinates");
				
		// Trim white spaces
		line2 = line;
		while( line2[0] == ' ' )
			line2++;
				
		// Read and set x value
		sscanf( line2, "%f", &x );
		object( 0, 2*i ) = x;
				
		// Trim data
		while( line2[0] != ' ' )
			line2++;
		while( line2[0] == ' ' )
			line2++;
				
		// Read and set y value
		sscanf( line2, "%f", &y );
		object( 0, 2*i+1 ) = y;
	}
			
	// Close file
	sourceFile.close();
}

/**
 * Performs the Procrustes Analysis on the objects: the param. objects is updated
 * @param objects objects are described in columns
 */
void procrustesAnalysis (CImg<float>& objects)
{
	//we consider that the first contour in objects is a reference contour and all the other contours are aligned to this one 
	//get number of points and number of contours (number of objects)
	int numPoints = objects.dimy()/2;
	int numObjects = objects.dimx();

	////////////////center and rescale the reference shape///////////////////////
	//initialize the coordinates of the center of the reference 
	float xCenterReferenceShape =0, yCenterReferenceShape=0; 
	
	//compute the coordinates of the center of the reference 
	/* TODO  */

	//initialize the scale of the reference 
	float scaleReferenceShape = 0;

	//compute the scale of the reference 
	/* TODO  */

	//center and rescale the reference
	/* TODO  */

	///////////////////////// Compute the centroids of the shapes////////////////////////
	
	//for each contour which is not a reference
	for (int k = 1; k<numObjects;k++)
	{
		//initialize the coordinates of the center of the current contour
		float xCenterSourceShape=0, yCenterSourceShape=0 ;
		//compute the coordinates of the center of the current contour
		/* TODO  */

		// Compute the scale of the shapes
		float  scaleSourceShape = 0;
		/* TODO  */
		

		//center and rescale the current contour
		/* TODO  */
		

		//compute the correlation matrix Corr
		CImg <float> corr (2,2) ;
		/* TODO  */


		CImg <float> U ,S, V ; 
		// Singular Value decomposition of matrix Corr
		corr.SVD(U,S,V);
		
		//compute the rotation matrix 
		CImg <float> rotationMatrix (2,2) ;
		/* TODO : rotationMatrix = ........... */

		//rotate the current contour
		/* TODO  */
		

	}

}


/**
 * Display an object described by a CImg vector: x_0,y_0,x_1,y_1...x_n,y_n 
 * @param object 
 * @param displayWindow
 * @param maxWindowSize 
 */
void displayObjects(  CImg<float> object, 
		     CImgDisplay& displayWindow,
		     int maxWindowSize = 500 )
{
	
	if( object.dimx() <= 0 || object.dimy()%2 != 0 )
		throw EcpException("displayContour: contour does not have the right size");
				
	int dimension = object.dimy()/2;
	// Find maximum coordinates
	float maxX = -1000, maxY = -1000;
	float minX = 10000, minY = 10000;
	for( int n = 0; n < object.dimx(); n++ )
	{
		for( int c = 0; c < dimension; c++ )
		{
			float x = object( n, 2*c );
			float y = object( n, 2*c+1 );
			if( x > maxX )
				maxX = x;
			if( x < minX )
				minX = x;
			if( y > maxY )
				maxY = y;
			if( y < minY )
				minY = y;
		}
	}
	float width  = maxX - minX;
	float height = maxY - minY;
	
	float factor = ( width > height )? (float)maxWindowSize/width : (float)maxWindowSize/height;
	
	// Create image
	CImg<unsigned char> displayImg( (int)round( width*factor  + 1 ), 
					(int)round( height*factor + 1 ) );
	unsigned char black[3] = {0,0,0};
	unsigned char white[3] = {255,255,255};
	displayImg.fill( white[0], white[1], white[2] );
			
	// Place points and draw lines
	int x1, x2, y1, y2;
	for( int c = 1; c < dimension; c++ )
	{
		x1 = (int)round( factor*( object( 0, 2*(c-1) ) - minX ) );
		y1 = (int)round( factor*( object( 0, 2*(c-1)+1 ) - minY ) );
				
		x2 = (int)round( factor*( object( 0, 2*c ) - minX ) );
		y2 = (int)round( factor*( object( 0, 2*c+1 ) - minY ) );
				
		displayImg.draw_line( x1, y1, x2, y2, black );
	}
	
	//Added by Ahmed to close the shape

	x1 = (int)round( factor*( object( 0, 0 ) - minX ) );
	y1 = (int)round( factor*( object( 0, 1 ) - minY ) );
				
	x2 = (int)round( factor*( object( 0, 2*(dimension-1) ) - minX ) );
	y2 = (int)round( factor*( object( 0, 2*(dimension-1)+1 ) - minY ) );
				
	displayImg.draw_line( x1, y1, x2, y2, black );
	
	//Added by Ahmed to draw points
	for( int n = 0; n < object.dimx(); n++ )
	{
		for( int c = 0; c < dimension; c++ )
		{

			x2 = (int)round( factor*( object( n, 2*c ) - minX ) );
			y2 = (int)round( factor*( object( n, 2*c+1 ) - minY ) );

			displayImg.draw_circle( x2, y2, 3, black );
		}
	}
	// Display
	displayWindow.resize( displayImg );
	displayImg.display( displayWindow );
}

/**
 * Display an object described by a CImg vector: x_0,y_0,x_1,y_1...x_n,y_n 
 * @param object 
 * @param displayWindow
 * @param maxWindowSize 
 */
void displayObject(  CImg<float> object, 
		     CImgDisplay& displayWindow,
		     int maxWindowSize = 500 )
{
	
	if( object.dimx() <= 0 || object.dimy()%2 != 0 )
		throw EcpException("displayContour: contour does not have the right size");
				
	int dimension = object.dimy()/2;
	// Find maximum coordinates
	float maxX = -1000, maxY = -1000;
	float minX = 10000, minY = 10000;
	for( int c = 0; c < dimension; c++ )
	{
		float x = object( 0, 2*c );
		float y = object( 0, 2*c+1 );
		if( x > maxX )
			maxX = x;
		if( x < minX )
			minX = x;
		if( y > maxY )
			maxY = y;
		if( y < minY )
			minY = y;
	}
		
	float width  = maxX - minX;
	float height = maxY - minY;
	
	float factor = ( width > height )? (float)maxWindowSize/width : (float)maxWindowSize/height;
	
	// Create image
	CImg<unsigned char> displayImg( (int)round( width*factor  + 1 ), 
					(int)round( height*factor + 1 ) );
	unsigned char black[3] = {0,0,0};
	unsigned char white[3] = {255,255,255};
	displayImg.fill( white[0], white[1], white[2] );
			
	// Place points and draw lines
	int x1, x2, y1, y2;
	for( int c = 1; c < dimension; c++ )
	{
		x1 = (int)round( factor*( object( 0, 2*(c-1) ) - minX ) );
		y1 = (int)round( factor*( object( 0, 2*(c-1)+1 ) - minY ) );
				
		x2 = (int)round( factor*( object( 0, 2*c ) - minX ) );
		y2 = (int)round( factor*( object( 0, 2*c+1 ) - minY ) );
				
		displayImg.draw_line( x1, y1, x2, y2, black );
	}
	
	//Added by Ahmed to close the shape

	x1 = (int)round( factor*( object( 0, 0 ) - minX ) );
	y1 = (int)round( factor*( object( 0, 1 ) - minY ) );
				
	x2 = (int)round( factor*( object( 0, 2*(dimension-1) ) - minX ) );
	y2 = (int)round( factor*( object( 0, 2*(dimension-1)+1 ) - minY ) );
				
	displayImg.draw_line( x1, y1, x2, y2, black );
	
	//Added by Ahmed to draw points
	for( int c = 0; c < dimension; c++ )
	{
				
		x2 = (int)round( factor*( object( 0, 2*c ) - minX ) );
		y2 = (int)round( factor*( object( 0, 2*c+1 ) - minY ) );
				
		displayImg.draw_circle( x2, y2, 3, black );
	}
	// Display
	displayWindow.resize( displayImg );
	displayImg.display( displayWindow );
}

/**
 * Same as previous function but with different arguments
 * @param object 
 * @param maxWindowSize 
 * @param title 
 * @param wait 
 */
void displayObject( 	CImg<float> object, 
			int maxWindowSize = 500,
     			char* title = "This is a tremendous contour.",
     			bool wait = true )
{
	CImgDisplay displayWindow;
	displayWindow.set_title( title );
	displayObject( object, displayWindow, maxWindowSize );
	displayWindow.show();
	while( wait && !displayWindow.button )
		displayWindow.wait(); 
}


/**
 * Same as previous function but with different arguments
 * @param object 
 * @param maxWindowSize 
 * @param title 
 * @param wait 
 */
void displayObjects( 	CImg<float> object, 
			int maxWindowSize = 500,
     			char* title = "This is a tremendous contour.",
     			bool wait = true )
{
	CImgDisplay displayWindow;
	displayWindow.set_title( title );
	displayObjects( object, displayWindow, maxWindowSize );
	displayWindow.show();
	while( wait && !displayWindow.button )
		displayWindow.wait(); 
}
/**
 * Compute the average value, the covariance matrix, 
the eigenvalues and the associated eigenvectors of 
a list of objects.
 * @param objects objects are described in columns
 * @param average 
 * @param covariance 
 * @param eigenValues 
 * @param eigenVectors 
 */
void computeModel( const CImg<float>& objects, 
		   CImg<float>& average, 
   		   CImg<float>& covariance,
		   CImg<float>& eigenValues,
		   CImg<float>& eigenVectors )
{
	// Check we have more than 1 contour
	int objectN = objects.dimx();
	if( objectN <= 0 )
		throw EcpException("computeStatistics: empty list of contours");
	
	int dimension = objects.dimy()/2;
	
	/////////////////////////////////////////////////
	// Resize the vectors if they have the wrong size
	/////////////////////////////////////////////////
	
	// average
	if( average.dimx() == 0 || average.dimy() == 0 )
		average.assign( 1, 2*dimension );
	else if( average.dimy() < 2*dimension )
		average.resize( 1, 2*dimension );
	
	// covariance
	if( covariance.dimx() == 0 || covariance.dimy() == 0 )
		covariance.assign( 2*dimension, 2*dimension );
	else if( covariance.dimx() < 2*dimension || covariance.dimy() < 2*dimension )
		covariance.resize( 2*dimension, 2*dimension );
	
	// eigenValues
	if( eigenValues.dimx() == 0 || eigenValues.dimy() == 0 )
		eigenValues.assign( 1, 2*dimension );
	else if( eigenValues.dimy() < 2*dimension )
		eigenValues.resize( 1, 2*dimension );
	
	// eigenVectors
	if( eigenVectors.dimx() == 0 || eigenVectors.dimy() == 0 )
		eigenVectors.assign( 2*dimension, 2*dimension );
	else if( eigenVectors.dimx() < 2*dimension || eigenVectors.dimy() < 2*dimension )
		covariance.resize( 2*dimension, 2*dimension );
	
	//////////////////////////
	// Compute average contour
	//////////////////////////
	average.fill(0);// set all values in average to zero
	/* TODO  */
	
	////////////////////////////////////////////////////////////////
	// Compute covariance = sum_i( contour#i * contour#i' )/contourN
	////////////////////////////////////////////////////////////////
	covariance.fill(0);
	/* TODO  */
	
	/////////////////////////////////////////
	// Compute eigen vectors and eigen values
	/////////////////////////////////////////
	/* TODO  */
}

/**
 * Display a weighted sum of eigenvectors: 
each weight is comprised between -3*sqrt(lambda) 
and +3*sqrt(lambda) where lambda is the eigen value associated to the eigen vector
 * @param average mean value
 * @param eigenValues column vector of eigen values
 * @param eigenVectors the columns of this CImg form the list of eigen vectors
 * @param nVectors the first nVectors eigen vectors will be used to compute the weighted sum
 */
void displayEigenVectors( const CImg<float> average, const CImg<float>& eigenValues, const CImg<float>& eigenVectors, int nVectors = 1 )
{
	// Check arguments
	if( eigenValues.dimx() == 0 || eigenVectors.dimx() == 0 || eigenValues.dimy() != eigenVectors.dimx() )
		throw EcpException("displayEigenVectors: wrong size of input arguments");
	if( nVectors <= 0 )
		nVectors = 1;
	if( nVectors > eigenVectors.dimx() )
		nVectors = eigenVectors.dimx();
	
	// Diverse variables
	int dimension = eigenValues.dimy();
	bool initialization = true;
	
	// Make the trackbars window
	CImg<float> trackbars( 100, 20*nVectors, 1, 3, 0 );
	CImgDisplay trackbarsDisp( trackbars, "Trackbars" );
	
	// Make the object window
	CImgDisplay objectDisplay;
	objectDisplay.set_title( "Weighted sum of eigen vectors" );
	
	// Initiliaze trackbars positions
	CImg<float> trackbarPos( 1, nVectors );
	trackbarPos.fill(0);
	
	while( true )
	{
		if( !initialization )
			trackbarsDisp.wait();
		// If mouse clic
		if( initialization || (trackbarsDisp.button && 
		    trackbarsDisp.mouse_x >= 0 && trackbarsDisp.mouse_x < trackbarsDisp.dimx() && 
		    trackbarsDisp.mouse_y >= 0 && trackbarsDisp.mouse_y < trackbarsDisp.dimy() ) )
		{
			// Get mouse position
			if( !initialization )
			{
				int x = trackbarsDisp.mouse_x;
				int y = trackbarsDisp.mouse_y;
				int vectorIndex = (int)floor( y/20.0 );
				float lambda = eigenValues( 0,vectorIndex );
				trackbarPos( 0, vectorIndex ) = -3.0*sqrt(lambda) + x*0.01*6.0*sqrt(lambda);
			}
			initialization = false;
			
			// Paint trackbars
			for( int v = 0; v < nVectors; v++ )
			{
				float lambda = eigenValues( 0,v );
				for( int x = 0; x < 100; x++ )
				{
					for( int y = -10; y < 10; y++ )
					{
						float color[3];
						if( - 3.0*sqrt(lambda) + x*0.01*6*sqrt(lambda) < trackbarPos(0,v) )
							color[0] = 255.0*abs(y)/10.0;
						else
							color[0] = 255;
						color[1] = 255;
						color[2] = 255;
						
						trackbars(x, 20*v+y+10, 0, 0 ) = color[0];
						trackbars(x, 20*v+y+10, 0, 1 ) = color[1];
						trackbars(x, 20*v+y+10, 0, 2 ) = color[2];
					}
				}
				// Write trackbar position
				char text[20];
				sprintf( text, "%f", trackbarPos(0,v) );
				float colorText[3] = {0,0,255};
				trackbars.draw_text( text, 5, 20*v, colorText );
			}
			
			// Display trackbars
			trackbars.display( trackbarsDisp );
			
			// Compute contour to be displayed
			CImg<float> totalVector( average );
			for( int v = 0; v < nVectors; v++ )
			{
				CImg<float> addedVector = eigenVectors.get_crop( v, v );
				addedVector *= trackbarPos( 0, v );
				totalVector += addedVector;
			}
			
			// Display contour
			displayObject( totalVector, objectDisplay, 500 );
			objectDisplay.show();
		}
	}
}

/**
 * Load a bunch of objects from a list of text files
 * @param objects The objects will be stored as the columns of this CImg.
 * @param path "/home/" or "C:\placetogo\". DO NOT forget the trailing slash / or antislash \.
 * @param prefix prefix of each file
 * @param indexMin the files should be indexed by a number with no trailing 0 (no such thing as "01" for instance).
 * @param indexMax 
 * @param indexStep 
 * @param extension could be anything
 */
void loadFromFiles( CImg<float>& objects, char* path, char* prefix, 
		    int indexMin, int indexMax, int indexStep, 
      		    char* extension )
{
	char fileName[1000];
	CImg<float> newObject(1,1);
	for( int index = indexMin; index <= indexMax; index += indexStep )
	{
		// Create new contour
		sprintf( fileName, "%s%s%d.%s", path, prefix, index, extension );
		makeObjectFromFile( fileName, newObject );
		
		// Append new contour to contours
		objects.append(newObject);
	}
	//center rescale rotate objects
	displayObjects( objects,500,"Unaligned Objects");
}
#endif
