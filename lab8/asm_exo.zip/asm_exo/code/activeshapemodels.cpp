// Usual libraries
#include <iostream>

// CImg library
#include "CImg.h"
using namespace cimg_library;

// Stl
#include <vector>
using namespace std;
 
// Custom libraries
#include "libECP.h"

int main(int argc, char *argv[])
{
	CImg<float> objects;
	char* path = "./Bones/";
	char* prefix = "Coordinates";
	char* extension = "txt";

	loadFromFiles( objects, path,
		       prefix, 1, 40, 1, extension );
	cout << objects.dimx() << " contours were found" << endl;
	CImg<float> Bones1("./Bones/bones1.tif");
	CImg<float> Bones2("./Bones/bones2.tif");
	int x,y;
	float black[3] = {0,0,0};
	for( int c = 0; c < objects.dimy()/2; c++ )
	{
		x = (int)round( objects( 0, 2*c ) );
		y = (int)round( objects( 0, 2*c+1 ) );

		Bones1.draw_circle( x, y, 3, black );

		x = (int)round( objects( 1, 2*c ) );
		y = (int)round( objects( 1, 2*c+1 ) );
		Bones2.draw_circle( x, y, 3, black );
	}
	CImgDisplay B1(Bones1,"Data: Example 1");
	while( !B1.button )
		B1.wait(); 
	CImgDisplay B2(Bones2,"Data: Example 2");
	while( !B2.button )
		B2.wait(); 

	procrustesAnalysis (objects);
	displayObjects( objects,500,"Aligned Objects");
	// Initialize matrices
	CImg<float> average;
	CImg<float> covariance;
	CImg<float> eigenValues;
	CImg<float> eigenVectors;
	
	// Compute average model, eigen values and eigen vectors
	computeModel( objects, average, covariance, 
		       eigenValues, eigenVectors );
	
	//////////////////
	// Display results
	//////////////////
	
	// average
	displayObject( average, 300, "average", true );
	
	// eigen values
	cout << "number of eigenvalues: (should be 144) " << eigenValues.dimy() << endl;
	for( int i = 0; i < eigenValues.dimy(); i++ )
		cout << "[" << i << "]" << eigenValues(0,i) << endl;
	
	// eigen vectors
	displayEigenVectors( average, eigenValues, eigenVectors, 10 );
	
	return 0;
}
