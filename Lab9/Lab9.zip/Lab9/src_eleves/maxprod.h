
#ifndef _MAXPRODUCT_H_INCLUDED_
#define _MAXPRODUCT_H_INCLUDED_

#include "CImg.h"

#include <vector>
#include <iostream>
#include <string>
#include <sstream>
#include <fstream>

#define minMacro(x,y) (x)<(y)?(x):(y)
#define maxMacro(x,y) (x)>(y)?(x):(y)

// set this flag to false to use normal products
// set this flag to true to use log products (faster)
#define LOG_SUM false 
#define EPSILON 1e-5

typedef cimg_library::CImg<float> Image;
float RED[3] = {255,0,0};

inline std::string int2string( int x, int minLength = 0 ){
	char truc[20];
	sprintf( truc, "%d", x );
	
	std::string txt(truc);
	while( txt.size() < minLength )
		txt = "0" + txt;
	
	return txt;
}

// multiply image src1 with image src2 and returns the result in image dst
void multiply( const Image& src1, const Image& src2, Image& dst ){
	int width = src1.dimx();
	int height = src1.dimy();
	for( int x = 0; x < width; x++ )
		for( int y = 0; y < height; y++ )
			dst(x,y) = src1(x,y)*src2(x,y);
}

void log( Image& img ){
	int width = img.dimx();
	int height = img.dimy();
	float val;
	for( int x = 0; x < width; x++ )
	{
		for( int y = 0; y < height; y++ )
		{
			img(x,y) = log( img(x,y) + EPSILON );
		}
	}
}

// Gaussian mean and covariance values for the binary potentials
float model_parameters[4][6] = { 
	{23.7431,30.1395,8.5802,-1.1769,-1.1769,17.4100},
	{-25.3161,30.2826,6.8709,-0.0325,-0.0325,17.1563},
	{20.8230,-23.0794,14.5850,-1.1840,-1.1840,18.0683},
	{-20.7654,-23.0412,10.9221,-1.1266,-1.1266,15.4599} };

	
void load_image( const char* path, Image& img ){
	std::fstream file( path, std::ios_base::in);
	std::string line;
	
	// Read width and height in first lines
	int width, height;
	{
		std::getline( file, line );
		std::stringstream str(line);
		str >> height;
		str >> width;
	}
	
	// Read every line
	img.assign(width,height);
	float val;
	for( int l = 0; l < height; l++ )
	{
		std::getline( file, line );
		std::stringstream str(line);
		
		// Add a line
		for( int i = 0; i < width; i++ )
		{
			str >> val;
			img(i,l) = val;
		}
	}
}

void draw_cross( Image& img, int x, int y, int R, int G, int B ){
	int radius = 5;
	int thick = 1;
	float color[3] = {R,G,B};
	img.draw_rectangle( x-thick, y-radius, x+thick, y+radius, color );
	img.draw_rectangle( x-radius, y-thick, x+radius, y+thick, color );
}

class Gaussian2D{
	public:
		// Constructors
		Gaussian2D(){
			this->mu1_ = 0;
			this->mu2_ = 0;
			this->sigma11_ = 0;
			this->sigma22_ = 0;
			this->sigma12_ = 0;
			this->det_  = 1;
			this->norm_ = 0;
		}
		Gaussian2D( float mu1, float mu2, float sigma11, float sigma22 ){
			this->mu1_ = mu1;
			this->mu2_ = mu2;
			
			this->sigma11_ = sigma11;
			this->sigma22_ = sigma22;
			this->sigma12_ = 0;
			
			this->det_  = this->det();
			this->norm_ = this->norm();
		}
		
		Gaussian2D( float mu1, float mu2, float sigma11, float sigma22, float sigma12 ){
			this->mu1_ = mu1;
			this->mu2_ = mu2;
			
			this->sigma11_ = sigma11;
			this->sigma22_ = sigma22;
			this->sigma12_ = sigma12;
			
			this->det_  = this->det();
			this->norm_ = this->norm();
		}
		
		Gaussian2D( const Gaussian2D& src ){
			*this = src;
		}
		
		Gaussian2D& operator=( const Gaussian2D& src ){
			this->mu1_ = src.mu1_;
			this->mu2_ = src.mu2_;
			
			this->sigma11_ = src.sigma11_;
			this->sigma22_ = src.sigma22_;
			this->sigma12_ = src.sigma12_;
			
			this->det_  = src.det_;
			this->norm_ = src.norm_;
			
			return *this;
		}
		
		float operator()( float x, float y ) const {
			float dx = x - this->mu1_;
			float dy = y - this->mu2_;
			float val = dx*dx*this->sigma22_ + dy*dy*this->sigma11_ - 2*dx*dy*this->sigma12_;
			if( LOG_SUM )
				val = -0.5*val + this->norm_;
			else
				val = exp(-0.5*val)*this->norm_;
			return val;
		}
		
		float operator()( int x1, int y1, int x2, int y2 ) const {
			return (*this)( x1 - x2, y1 - y2 );
		}
		
		float det() const {
			return this->sigma11_*this->sigma22_ - this->sigma12_*this->sigma12_;
		}
		float norm() const {
			float val = 1.0/( 2*3.14159653*sqrt( this->det_ ) ) ;
			if( LOG_SUM )
				return log(val+EPSILON);
			return val;
		}
		
		
		const float& mu1() const { return this->mu1_; }
		const float& mu2() const { return this->mu2_; }
		
	private:
		float sigma11_, sigma22_, sigma12_;
		float mu1_, mu2_;
		float norm_, det_;
};

class Node{
	public:
		Node(){}
		
		// index: 0=nose, > 0 => something else
		Node( const std::string& imgName, int index){
			// Load unary potential
			load_image( imgName.c_str(), this->unary_ );
			if( LOG_SUM )
				log( this->unary_ );
			this->index_ = index;
			
			// Belief image
			this->belief_.assign( this->dimx(), this->dimy() );
			this->belief_.fill(0);
		}
		Node( const Node& src ){
			*this = src;
		}
		
		Node& operator=( const Node& src ){
			this->message_ = src.message_;
			this->unary_ = src.unary_;
			this->belief_ = src.belief_;
			
			this->param_ = src.param_;
			this->neigh_ = src.neigh_;
			this->message_computed_ = src.message_computed_;
			this->index_ = src.index_;
			
			return *this;
		}
		
		int dimx() const { return this->unary_.dimx(); }
		int dimy() const { return this->unary_.dimy(); }
		
		// return the index the Node (root index = 0, left eye = 1, etc. )
		int index() const { return this->index_; }
		
		// return the ith neighbor of this Node
		// notice that i IS NOT the index of the node
		const Node& neigh( int i ) const { return *this->neigh_[i]; }
		Node& neigh( int i ){ return *this->neigh_[i]; }
		
		// return the number of neighbors of this Node
		int neighN() const { return this->neigh_.size(); }
		
		// return the message arriving at this Node and emitted 
		// by the ith neighbor of this Node
		const Image& message(int i) const { return this->message_[i]; }
		
		// return true if the message from the ith neighbor to this Node 
		// was already computed
		bool message_computed(int i) const { return this->message_computed_[i]; }
		
		// return the belief function of this Node
		const Image& belief() const { return this->belief_; }
		
		// return the unary_potential associated with this Node
		const Image& unary_potential() const { return this->unary_; }
	
		// return the value of the unary potential associated with this Node
		// at coordinates x,y
		float unary_potential( int x, int y ) const {
			float val = this->unary_(x,y);
			return this->unary_(x,y);
		}
		
		// return the value of the binary potential of the pair (N,Ni), where
		// N is this Node, and Ni its ith neighbor
		// ( binary_potential = Psi( this, Neighbor(i) )
		// (x,y) is the location of N
		// (xi,yi) is the location of Ni
		float binary_potential( int x, int y, 
					int i, int xi, int yi ) const 
		{
			return this->param_[i]( x, y, xi, yi );
		}
		
		// (do not try to understand this)
		void bounding_box( int x, int y, int i, int& xmin, int& xmax, int& ymin, int& ymax) const
		{
			int winRadius= 25;
			float mu1 = this->param_[i].mu1();
			float mu2 = this->param_[i].mu2();
			xmin = minMacro( maxMacro( x - (int)mu1 - winRadius, 0) , this->dimx() );
			xmax = minMacro( maxMacro( x - (int)mu1 + winRadius, 0) , this->dimx() );
			ymin = minMacro( maxMacro( y - (int)mu2 - winRadius, 0) , this->dimy() );
			ymax = minMacro( maxMacro( y - (int)mu2 + winRadius, 0) , this->dimy() );
			// std::cout<<"bounding box for node "<<i<<" ["<<xr<<","<<yr<<"]: "
			//          <<"mx="<<mx<<", my="<<my<<", "
			//          <<xmin<<", "<<xmax<<", "<<ymin<<", "<<ymax<<std::endl;
		}
		
		// compute the product of all messages incoming to this instance of Node
		// EXCEPT for its neighbor exclude
		float message_product( Image& msg_product, int exclude ){
			for( int n = 0; n < this->neighN(); n++ )
			{
				int neighIndex = this->neigh(n).index();
				if( neighIndex != exclude )
				{
					this->compute_message(n);
					if( LOG_SUM )
					{
						//TODO 3.2
						// compute the sum (actually, it's the log product) 
						// of the messages incomming to this Node
						// You can access the messages with this->message(int)
						// msg_product += ?
						msg_product += 0;
					}
					else
					{
						//TODO 3.1
						// (note: use the function multiply(Image,Image,Image) 
						// defined above for multiplying two images )
						msg_product *= 1;
					}
						
				}
			}
		}
		
		// Compute the message arriving at this Node from its ith neighbor
		void compute_message( int i ){
			if( this->message_computed(i) )
				return;
		
			Image msg_product( this->dimx(), this->dimy() );
			if( LOG_SUM )
				msg_product.fill(0);
			else
				msg_product.fill(1);
			this->neigh(i).message_product( msg_product, this->index() );
			
			int xi_min, yi_min, xi_max, yi_max;
			float phi, psi;
			for( int xj = 0; xj < this->dimx(); xj++ ){
			for( int yj = 0; yj < this->dimy(); yj++ )
			{
				this->bounding_box( xj, yj, i, xi_min, xi_max, yi_min, yi_max);
				float msg;
				float msg_max = -1000000;// can you come up with a smarter value ?
				for( int xi = xi_min; xi < xi_max; xi++ ){
				for( int yi = yi_min; yi < yi_max; yi++ )
				{
					if( LOG_SUM )
					{
						// TODO 2.2
						// compute msg using methods from the Node class (msg_product(), binary_potential(),
						// and unary_potential()
						msg=0;
						//msg=(...);
					}
					else
					{
						// TODO 2.1
						msg=1;
						//msg=(...);
					}
					if( msg != msg )
						std::cout << "NAN message" << std::endl;
					msg_max = maxMacro(msg,msg_max);
				}
				}
				this->message_[i](xj,yj) = msg_max;
			}
			}
			this->message_computed_[i] = true;
		}
		inline void compute_messages(){
			for( int n = 0; n < this->neighN(); n++ )
				this->compute_message(n);
		}
		
		// compute the Belief messages Bi(xi) (cf. instruction sheet)
		void compute_belief(){
			this->compute_messages();
			
			this->belief_ = this->unary_;
			for( int n = 0; n < this->neighN(); n++ )
			{
				if( LOG_SUM )
				{
					// TODO 1.2
					// compute the sum (ie the log product) of the messages incomming
					// to this Node.
					// You can access the messages with this->message(int)
					//this->belief_ += ?
					this->belief_ += 0;
				}
				else
				{
					// TODO 1.1
					//this->belief_ += ?
					// (note: use the function multiply(Image,Image,Image) 
					// defined above for multiplying two images )
					this->belief_ *= 1;
				}
			}
		}
		
		// find the arg max of the belief function
		void best_belief( int& x, int& y ) const {
			// TODO 4
			// x=?
			// y=?
		}
		
		// (baaah)
		void add_neighbour( Node& neigh ){
			// Load Gaussian parameters if 
			int index_i = this->index();
			int index_j = neigh.index();
			if( index_i == 0 && index_j == 0 )
				std::cout << "WARNING: connecting root with itself" << std::endl;
			if( index_i != 0 && index_j != 0 )
				std::cout << "WARNING: connecting non-root nodes" << std::endl;
			float m1, m2, s11, s22, s12;
			if( index_i == 0 )	// Node is root
			{
				m1 = model_parameters[index_j-1][0];
				m2 = model_parameters[index_j-1][1];
				s11 = model_parameters[index_j-1][2];
				s12 = model_parameters[index_j-1][3];
				s22 = model_parameters[index_j-1][5];
			}
			else			// Node is not root
			{
				m1 = -model_parameters[index_i-1][0];
				m2 = -model_parameters[index_i-1][1];
				s11 = model_parameters[index_i-1][2];
				s12 = model_parameters[index_i-1][3];
				s22 = model_parameters[index_i-1][5];
			}
			
			this->param_.push_back( Gaussian2D(m1, m2, s11, s22, s12) );
			this->neigh_.push_back( &neigh );
			this->message_.push_back( Image( this->dimx(), this->dimy(), 1, 1, 1 ) );
			this->message_computed_.push_back(false);
		}		
		
					
	private:
		std::vector<Image> message_;
		Image unary_;
		Image belief_;

		std::vector<Gaussian2D> param_;
		std::vector<Node*> neigh_;
		std::vector<bool> message_computed_;
		int index_;
};

class MaxProduct{
	public:
		// Constructors
		MaxProduct( const std::string& imgName ){
			this->testImage_.assign( imgName.c_str() );
			
			this->find_image_prefix( imgName );
			
			// Load nodes
			for( int i = 0; i < 5; i++ ){
				std::string filename = imagePrefix_ + "_node-" + int2string(i) + imageFormat_;
				this->node_.push_back( Node( filename, i ) );
				
// 				// Display log values of unary potentials
// 				this->node(i).unary_potential().display( ("Unary potential of node " + int2string(i)).c_str() );
			}
			
			// Connect nodes
			for( int i = 1; i < 5; i++ )
			{
				this->root().add_neighbour( this->node(i) );
				this->node(i).add_neighbour( this->root() );
			}
		}
		
		MaxProduct( const MaxProduct& src ){
			*this = src;
		}
		
		MaxProduct& operator=( const MaxProduct& src ){
			this->node_ = src.node_;
			this->imageFormat_ = src.imageFormat_;
			this->imagePrefix_ = src.imagePrefix_;
			return *this;
		}
		
		inline int dimx() const { return this->testImage_.dimx(); }
		inline int dimy() const { return this->testImage_.dimy(); }
		
		inline const Node& node(int i) const { return this->node_[i]; }
		inline Node& node(int i){ return this->node_[i]; }
		inline const Node& root() const { return this->node_[0]; }
		inline Node& root(){ return this->node_[0]; }
		
		void do_all()
		{
			// Compute belief and find best node position estimation
			std::vector<int> x_best(5), y_best(5);
			for( int i = 0; i < 5; i++ )
			{
				std::cout << "Computing belief of node " << i << std::endl;
				this->node(i).compute_belief();
				this->node(i).best_belief(x_best[i],y_best[i]);
			}
			
			// Display estimated positions
			Image disp_image(this->testImage_);
			draw_cross( disp_image, x_best[0], y_best[0], 255, 255, 255 );
			draw_cross( disp_image, x_best[1], y_best[1], 255, 0, 0 );
			draw_cross( disp_image, x_best[2], y_best[2], 0, 255, 0 );
			draw_cross( disp_image, x_best[3], y_best[3], 0, 0, 255 );
			draw_cross( disp_image, x_best[4], y_best[4], 255, 255, 0 );
			disp_image.display( "Detection" );
			
			for( int i = 0; i < 5; i++ )
				this->node(i).belief().display( ("Belief of node " + int2string(i)).c_str() );
		}
					
	private:
		Image testImage_;// source image
		std::string imageFormat_;
		std::string imagePrefix_;
		
		// Children and root nodes
		std::vector<Node> node_;
		
		// Useful methods
		void find_image_prefix( const std::string& filename )
		{
			std::string::size_type idx;
			idx = filename.rfind('.');
			if(idx != std::string::npos) {
				//this->imageFormat_ = filename.substr( idx );
				this->imagePrefix_ = filename.substr( 0, idx );
			}
			else {
				// No extension found
			}
			imageFormat_ = ".txt";	
		}
};

#endif



