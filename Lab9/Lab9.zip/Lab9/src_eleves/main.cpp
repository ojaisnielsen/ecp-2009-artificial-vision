#include "CImg.h"
#include "maxprod.h"
#include <iostream>
#include <string>

#ifdef _WIN32
  std::string delim = "\\";
#else
  std::string delim = "/";
#endif

int main( int argN, char* args[] )
{
	int nImages = 5;
	std::string fileNames[5] = { "image_1.png", "image_101.png", "image_121.png", "image_141.png", "image_161.png" };
	
	std::cout<<"Choose an image to process from this list:"<<std::endl;
	int imageIndex;
	for( int i = 0; i < nImages; i++ )
	{    
		std::cout<<i<<": "<<fileNames[i]<<std::endl;
	}
	std::cout<<"Chose an integer between 0 and "<<nImages-1<<": ";
	std::cin >> imageIndex;
	
	while( ( imageIndex < 0 ) || ( imageIndex >= nImages ) )
	{
		std::cout<<"You must chose an integer BETWEEN 0 and "
		<<nImages-1<<": ";
		std::cin >> imageIndex;
	}
	
	std::string path = ".." + delim + "images" + delim;
	MaxProduct maxp( path+fileNames[imageIndex] );
	maxp.do_all();
	
	return 0;
}
